/*
 * $Header$
 *
 * DO NOT EDIT
 * automagically generated from the projectDefinition: mocks_hg_p4.
 */
#define __INDIRECTVMINITCALLS__
#include <stc.h>

#ifdef WIN32
# pragma codeseg INITCODE "INITCODE"
#endif

#if defined(INIT_TEXT_SECTION) || defined(DLL_EXPORT)
DLL_EXPORT void _libmocks_hg_p4_Init() INIT_TEXT_SECTION;
DLL_EXPORT void _libmocks_hg_p4_InitDefinition() INIT_TEXT_SECTION;
#endif

void _libmocks_hg_p4_InitDefinition(pass, __pRT__, snd)
OBJ snd; struct __vmData__ *__pRT__; {
__BEGIN_PACKAGE2__("libmocks_hg_p4__DFN", _libmocks_hg_p4_InitDefinition, "mocks:hg/p4");
_mocks_137hg_137p4_Init(pass,__pRT__,snd);

__END_PACKAGE__();
}

void _libmocks_hg_p4_Init(pass, __pRT__, snd)
OBJ snd; struct __vmData__ *__pRT__; {
__BEGIN_PACKAGE2__("libmocks_hg_p4", _libmocks_hg_p4_Init, "mocks:hg/p4");
_mocks_137hg_137p4_Init(pass,__pRT__,snd);

_mocks_137hg_137p4_extensions_Init(pass,__pRT__,snd);
__END_PACKAGE__();
}
