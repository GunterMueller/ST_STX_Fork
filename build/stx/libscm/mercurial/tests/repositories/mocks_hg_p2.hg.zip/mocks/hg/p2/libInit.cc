/*
 * $Header$
 *
 * DO NOT EDIT
 * automagically generated from the projectDefinition: mocks_hg_p2.
 */
#define __INDIRECTVMINITCALLS__
#include <stc.h>

#ifdef WIN32
# pragma codeseg INITCODE "INITCODE"
#endif

#if defined(INIT_TEXT_SECTION) || defined(DLL_EXPORT)
DLL_EXPORT void _libmocks_hg_p2_Init() INIT_TEXT_SECTION;
// DLL_EXPORT void _libmocks_hg_p2_InitDefinition() INIT_TEXT_SECTION;
#endif

// void _libmocks_hg_p2_InitDefinition(pass, __pRT__, snd)
// OBJ snd; struct __vmData__ *__pRT__; {
// __BEGIN_PACKAGE2__("libmocks_hg_p2__DFN", _libmocks_hg_p2_InitDefinition, "mocks:hg/p2");
// _mocks_137hg_137p2_Init(pass,__pRT__,snd);

// __END_PACKAGE__();
// }

void _libmocks_hg_p2_Init(pass, __pRT__, snd)
OBJ snd; struct __vmData__ *__pRT__; {
__BEGIN_PACKAGE2__("libmocks_hg_p2", _libmocks_hg_p2_Init, "mocks:hg/p2");
_MocksHgP2Foo_Init(pass,__pRT__,snd);
_mocks_137hg_137p2_Init(pass,__pRT__,snd);


__END_PACKAGE__();
}
